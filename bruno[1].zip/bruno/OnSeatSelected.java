package com.takeoffandroid.seatBookingrecyclerView;

/**
 * Created by chandrasekar on 14/02/16.
 */
public interface OnSeatSelected {

    void onSeatSelected(int count);
}
